#include "MyMVS.h"

MV_CC_DEVICE_INFO_LIST m_stDevList;         // ch:�豸��Ϣ�б��ṹ������������洢�豸�б�
CMyCamera m_pcMyCamera;
bool OpenDevice = false;
bool StartGrabbingflag = false;
FnPtr myCallback;
int MODE;

ALEADER_API bool __stdcall InitImageCard(void)
{
	return false;
}

ALEADER_API bool __stdcall UnInitImageCard(void)
{
	return false;
}

ALEADER_API bool __stdcall InitCamera(void)
{
	if (OpenDevice)
		return true;
	if (m_pcMyCamera.EnumDevices(&m_stDevList))
		return false;
	if (NULL == m_stDevList.pDeviceInfo[0])
		return false;
	if (m_pcMyCamera.Open(m_stDevList.pDeviceInfo[0]))
		return false;
	if (m_pcMyCamera.RegisterImageCallBack(ImageCallBackEx, NULL))
		return false;

	if (m_pcMyCamera.SetEnumValue("BalanceWhiteAuto", 0))
		return false;
	if (m_pcMyCamera.SetEnumValue("BalanceRatioSelector", 0))
		return false;
	if (m_pcMyCamera.SetIntValue("BalanceRatio", 1536))
		return false;
	if (m_pcMyCamera.SetEnumValue("BalanceRatioSelector", 1))
		return false;
	if (m_pcMyCamera.SetIntValue("BalanceRatio", 1536))
		return false;
	if (m_pcMyCamera.SetEnumValue("BalanceRatioSelector", 2))
		return false;
	if (m_pcMyCamera.SetIntValue("BalanceRatio", 1536))
		return false;

	if (m_pcMyCamera.SetEnumValue("PixelFormat", 0x0108000B))
		return false;

	if (m_pcMyCamera.SetFloatValue("ResultingFrameRate", 1000))
		return false;

	if (m_pcMyCamera.SetBayerCvtQuality())
		return false;
	OpenDevice = true;
	if (!SetCameraTriggerMode(1))
	{
		OpenDevice = false;
		return false;
	}
	return true;
}

ALEADER_API bool __stdcall UnInitCamera(void)
{
	if (OpenDevice)
	{
		if (m_pcMyCamera.Close())
			return false;
		OpenDevice = false;
		StartGrabbingflag = false;
	}
	return true;
}

void __stdcall ImageCallBackEx(unsigned char * pData, MV_FRAME_OUT_INFO_EX* pFrameInfo, void* pUser)
{
	if (pFrameInfo)
	{
		if(myCallback)
			myCallback(pFrameInfo->nFrameLen, pFrameInfo->nWidth, pFrameInfo->nHeight, pFrameInfo->nFrameNum, 24, pData);
	}
}

ALEADER_API bool __stdcall RegisterCameraDataCallback(FnPtr funCallback)
{
	myCallback = funCallback;
	return true;
}

ALEADER_API bool __stdcall UnRegisterCameraDataCallback(void)
{
	if (myCallback != NULL)
		myCallback = NULL;
	return true;
}

bool setSoftTriggerConf()
{
	if (!OpenDevice)
		return false;
	if (m_pcMyCamera.SetEnumValue("TriggerMode", 1))
		return false;
	if (m_pcMyCamera.SetEnumValue("TriggerSource", 7))
		return false;
	return true;
}

bool setLineTriggerConf()
{
	if (!OpenDevice)
		return false;
	if (m_pcMyCamera.SetEnumValue("TriggerMode", 1))
		return false;
	if (m_pcMyCamera.SetEnumValue("TriggerSource", 0))
		return false;
	return true;
}

ALEADER_API bool __stdcall SetCameraTriggerMode(int mode)
{
	MODE = mode;
	if (mode)
	{
		return setSoftTriggerConf();
	}
	else
	{
		return setLineTriggerConf();
	}
}

ALEADER_API bool __stdcall SetCameraExposureTime(double Value)
{
	if (!OpenDevice)
	{
		return false;
	}
	if (m_pcMyCamera.SetEnumValue("ExposureMode", 0))
		return false;
	if (m_pcMyCamera.SetFloatValue("ExposureTime", Value))
		return false;
	return true;
}

ALEADER_API bool __stdcall SetCameraGainRaw(double Value)
{
	if (!OpenDevice)
	{
		return false;
	}
	if (m_pcMyCamera.SetEnumValue("GainAuto", 0))
		return false;
	if (m_pcMyCamera.SetFloatValue("Gain", Value))
		return false;
	return true;
}

ALEADER_API bool __stdcall SetReverseXY(bool ReverseX, bool ReverseY)
{
	if (m_pcMyCamera.SetBoolValue("ReverseX", ReverseX))
		return false;
	if (m_pcMyCamera.SetBoolValue("ReverseY", ReverseY))
		return false;
	return true;
}

ALEADER_API bool __stdcall StartCamera(void)
{
	if (!StartGrabbingflag)
	{
		if (m_pcMyCamera.StartGrabbing())
				return false;
		StartGrabbingflag = true;
	}
	if (MODE)
	{
		m_pcMyCamera.CommandExecute("TriggerSoftware");
	}
	return true;
}

ALEADER_API bool __stdcall StopCamera(void)
{
	if (StartGrabbingflag)
	{
		if (m_pcMyCamera.StopGrabbing())
			return false;
		StartGrabbingflag = false;
	}
	return true;
}

ALEADER_API const char* __stdcall GetSerialNumber(void)
{
	if (OpenDevice)
		return (const char*)(&(m_stDevList.pDeviceInfo[0]->SpecialInfo.stUsb3VInfo.chSerialNumber));
}

ALEADER_API const char* __stdcall GetCamerainfo(int *Width, int *Height)
{
	*Width = 2048;
	*Height = 2592;

	return "MVS";
}