#pragma once
#include "MyCamera.h"

#define ALEADER_API __declspec(dllexport)

typedef void(__stdcall *FnPtr)(int FrameSize, int width, int height, int DataFormat, int BoardBit, unsigned char * pUserBuffer);

extern "C"
{
	ALEADER_API bool __stdcall InitImageCard(void);
	ALEADER_API bool __stdcall UnInitImageCard(void);
	ALEADER_API bool __stdcall InitCamera(void);
	ALEADER_API bool __stdcall UnInitCamera(void);
	ALEADER_API bool __stdcall RegisterCameraDataCallback(FnPtr funCallback);
	ALEADER_API bool __stdcall UnRegisterCameraDataCallback(void);
	ALEADER_API bool __stdcall SetCameraTriggerMode(int mode);
	ALEADER_API bool __stdcall SetCameraExposureTime(double Value);
	ALEADER_API bool __stdcall SetCameraGainRaw(double Value);
	ALEADER_API bool __stdcall SetReverseXY(bool ReverseX, bool ReverseY);
	ALEADER_API bool __stdcall StartCamera(void);
	ALEADER_API bool __stdcall StopCamera(void);
	ALEADER_API const char* __stdcall GetSerialNumber(void);
	ALEADER_API const char* __stdcall GetCamerainfo(int *Width, int *Height);
}

void __stdcall ImageCallBackEx(unsigned char * pData, MV_FRAME_OUT_INFO_EX* pFrameInfo, void* pUser);

bool setSoftTriggerConf();
bool setLineTriggerConf();
