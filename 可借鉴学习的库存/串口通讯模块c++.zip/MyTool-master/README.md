# MyTool

## windows c++ 串口

### 位置

serial_win_cplus 项目中

### 内容

暂时只写了同步操作